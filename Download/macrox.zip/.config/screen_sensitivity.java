import java.util.*;

class ScriptableObject {
    public class MonoBehaviour {
        public String ClassName;
        public References references = new References();
        public Fields fields = new Fields();
        public Methods methods = new Methods();

        public class References {
            public Reference reference = new Reference();

            public class Reference {
                public String Name;
            }
        }

        public class Fields {
            public Field field = new Field();

            public class Field {
                public String Name;
                public String Type;
                public float Value;
            }
        }

        public class Methods {
            public Method method = new Method();

            public class Method {
                public String Name;
                public String ReturnType;
                public Statements statements = new Statements();

                public class Statements {
                    public Statement statement = new Statement();

                    public class Statement {
                        public DeclarationStatement declarationStatement = new DeclarationStatement();
                        public Expression expression = new Expression();

                        public class DeclarationStatement {
                            public String Type;
                            public String Name;
                            public Initializer initializer = new Initializer();

                            public class Initializer {
                                public Expression expression = new Expression();

                                public class Expression {
                                    public BinaryOperator binaryOperator = new BinaryOperator();

                                    public class BinaryOperator {
                                        public String Operator;
                                        public LeftOperand leftOperand = new LeftOperand();
                                        public RightOperand rightOperand = new RightOperand();

                                        public class LeftOperand {
                                            public BinaryOperator binaryOperator = new BinaryOperator();

                                            public class BinaryOperator {
                                                public CallExpression callExpression = new CallExpression();

                                                public class CallExpression {
                                                    public String Target;
                                                    public String MethodName;
                                                    public Arguments arguments = new Arguments();

                                                    public class Arguments {
                                                        public Argument argument = new Argument();

                                                        public class Argument {
                                                            public String StringLiteral;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    public class RightOperand {
                                        public CallExpression callExpression = new CallExpression();

                                        public class CallExpression {
                                            public String Target;
                                            public String MethodName;
                                            public Arguments arguments = new Arguments();

                                            public class Arguments {
                                                public Argument argument = new Argument();

                                                public class Argument {
                                                    public String StringLiteral;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        public class Expression {
                            public CallExpression callExpression = new CallExpression();
                            public GetProperty getProperty = new GetProperty();
                            public String NumberLiteral;

                            public class CallExpression {
                                public String Target;
                                public String MethodName;
                                public Arguments arguments = new Arguments();

                                public class Arguments {
                                    public Argument argument = new Argument();

                                    public class Argument {
                                        public String StringLiteral;
                                    }
                                }
                            }

                            public class GetProperty {
                                public String Target;
                                public String PropertyName;
                            }

                            public class UnaryOperator {
                                public String Operator;
                                public Operand operand = new Operand();

                                public class Operand {
                                    public GetProperty getProperty = new GetProperty();

                                    public class GetProperty {
                                        public String Target;
                                        public String PropertyName;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public MonoBehaviour monoBehaviour = new MonoBehaviour();
}

public class Main {
    public static void main(String[] args) {
        ScriptableObject scriptableObject = new ScriptableObject();
        ScriptableObject.MonoBehaviour mb = scriptableObject.monoBehaviour;

        mb.ClassName = "ScreenSensitivity";
        mb.references.reference.Name = "UnityEngine";
        mb.fields.field.Name = "sensitivity";
        mb.fields.field.Type = "float";
        mb.fields.field.Value = 900f;
        mb.methods.method.Name = "Update";
        mb.methods.method.ReturnType = "void";

        mb.methods.method.statements.statement.declarationStatement.Type = "Vector2";
        mb.methods.method.statements.statement.declarationStatement.Name = "input";
        mb.methods.method.statements.statement.declarationStatement.initializer.expression.binaryOperator.leftOperand.binaryOperator.callExpression.Target = "UnityEngine.Input";
        mb.methods.method.statements.statement.declarationStatement.initializer.expression.binaryOperator.leftOperand.binaryOperator.callExpression.MethodName = "GetAxis";
        mb.methods.method.statements.statement.declarationStatement.initializer.expression.binaryOperator.leftOperand.binaryOperator.callExpression.arguments.argument.StringLiteral = "Mouse X";
        mb.methods.method.statements.statement.declarationStatement.initializer.expression.binaryOperator.rightOperand.callExpression.Target = "UnityEngine.Input";
        mb.methods.method.statements.statement.declarationStatement.initializer.expression.binaryOperator.rightOperand.callExpression.MethodName = "GetAxis";
        mb.methods.method.statements.statement.declarationStatement.initializer.expression.binaryOperator.rightOperand.callExpression.arguments.argument.StringLiteral = "Mouse Y";
        mb.methods.method.statements.statement.declarationStatement.initializer.expression.binaryOperator.rightOperand.Variable = "sensitivity";

        mb.methods.method.statements.statement.expression.callExpression.Target = "transform";
        mb.methods.method.statements.statement.expression.callExpression.MethodName = "Rotate";
        mb.methods.method.statements.statement.expression.callExpression.arguments.argument.unaryOperator.Operator = "-";
        mb.methods.method.statements.statement.expression.callExpression.arguments.argument.unaryOperator.operand.getProperty.Target = "input";
        mb.methods.method.statements.statement.expression.callExpression.arguments.argument.unaryOperator.operand.getProperty.PropertyName = "y";
        mb.methods.method.statements.statement.expression.callExpression.arguments.argument.getProperty.Target = "input";
        mb.methods.method.statements.statement.expression.callExpression.arguments.argument.getProperty.PropertyName = "x";
        mb.methods.method.statements.statement.expression.callExpression.arguments.argument.NumberLiteral = "0f";
    }
}