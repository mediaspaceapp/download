let sightSensitivity = 900;

let inputHorizontal = UnityEngine.Input.GetAxis("Mouse X") * sightSensitivity;
let inputVertical = UnityEngine.Input.GetAxis("Mouse Y") * sightSensitivity;

transform.Rotate(-inputVertical, inputHorizontal, 0);
