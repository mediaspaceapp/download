const sensitivities = new Map();

sensitivities.set("ScreenX", 900);
sensitivities.set("ScreenY", 900);
sensitivities.set("Joystick", 900);
sensitivities.set("Aim", 900);
sensitivities.set("Shoot", 900);

console.log("<Sensitivities>");
for (const [name, value] of sensitivities) {
  console.log(`  <Sensitivity name="" value="" />`);
}
console.log("</Sensitivities>");
