class ScriptableObject {
    class MonoBehaviour {
        var ClassName: String = ""
        var references: References = References()
        var fields: Fields = Fields()
        var methods: Methods = Methods()

        class References {
            var reference: Reference = Reference()

            class Reference {
                var Name: String = ""
            }
        }

        class Fields {
            var field: Field = Field()

            class Field {
                var Name: String = ""
                var Type: String = ""
                var Value: Float = 0.0f
            }
        }

        class Methods {
            var method: Method = Method()

            class Method {
                var Name: String = ""
                var ReturnType: String = ""
                var statements: Statements = Statements()

                class Statements {
                    var statement: Statement = Statement()

                    class Statement {
                        var declarationStatement: DeclarationStatement = DeclarationStatement()
                        var expression: Expression = Expression()

                        class DeclarationStatement {
                            var Type: String = ""
                            var Name: String = ""
                            var initializer: Initializer = Initializer()

                            class Initializer {
                                var expression: Expression = Expression()
                            }
                        }

                        class Expression {
                            var callExpression: CallExpression = CallExpression()
                            var getProperty: GetProperty = GetProperty()
                            var NumberLiteral: String = ""
                            var unaryOperator: UnaryOperator = UnaryOperator()

                            class CallExpression {
                                var Target: String = ""
                                var MethodName: String = ""
                                var arguments: Arguments = Arguments()

                                class Arguments {
                                    var argument: Argument = Argument()

                                    class Argument {
                                        var StringLiteral: String = ""
                                    }
                                }
                            }

                            class GetProperty {
                                var Target: String = ""
                                var PropertyName: String = ""
                            }

                            class UnaryOperator {
                                var Operator: String = ""
                                var operand: Operand = Operand()

                                class Operand {
                                    var getProperty: GetProperty = GetProperty()
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    var monoBehaviour: MonoBehaviour = MonoBehaviour()
}

fun main() {
    val scriptableObject = ScriptableObject()
    val mb = scriptableObject.monoBehaviour

    mb.ClassName = "ScreenSensitivity"
    mb.references.reference.Name = "UnityEngine"
    mb.fields.field.Name = "sensitivity"
    mb.fields.field.Type = "float"
    mb.fields.field.Value = 900f
    mb.methods.method.Name = "Update"
    mb.methods.method.ReturnType = "void"

    // Correcting the access path and properties
    val initExpr = mb.methods.method.statements.statement.declarationStatement.initializer.expression
    initExpr.callExpression.Target = "UnityEngine.Input"
    initExpr.callExpression.MethodName = "GetAxis"
    initExpr.callExpression.arguments.argument.StringLiteral = "Mouse X"

    // Note: To properly handle multiple calls, separate variables or methods are recommended in real code
    val expr = mb.methods.method.statements.statement.expression
    expr.callExpression.Target = "transform"
    expr.callExpression.MethodName = "Rotate"
    expr.callExpression.arguments.argument.unaryOperator.Operator = "-"
    expr.callExpression.arguments.argument.unaryOperator.operand.getProperty.Target = "input"
    expr.callExpression.arguments.argument.unaryOperator.operand.getProperty.PropertyName = "y"
    expr.callExpression.arguments.argument.getProperty.Target = "input"
    expr.callExpression.arguments.argument.getProperty.PropertyName = "x"
    expr.callExpression.arguments.argument.NumberLiteral = "0f"
}