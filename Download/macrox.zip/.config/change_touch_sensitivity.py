import android

def change_touch_sensitivity(sensitivity_x, sensitivity_y):
  device = android.Device()
  window = device.get_active_window()
  touch_sensitivity_control_x = window.find_control("TouchSensitivityX")
  touch_sensitivity_control_y = window.find_control("TouchSensitivityY")
  touch_sensitivity_control_x.set_value(sensitivity_x)
  touch_sensitivity_control_y.set_value(sensitivity_y)

if __name__ == "__main__":
  sensitivity_x = 900
  sensitivity_y = 900
  change_touch_sensitivity(sensitivity_x, sensitivity_y)