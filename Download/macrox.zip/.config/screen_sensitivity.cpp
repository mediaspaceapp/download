#include <iostream>
#include <string>

// Definición de la clase ScriptableObject
class ScriptableObject {
public:
    class MonoBehaviour {
    public:
        std::string ClassName;

        class References {
        public:
            class Reference {
            public:
                std::string Name;
            };
            Reference reference;
        };
        References references;

        class Fields {
        public:
            class Field {
            public:
                std::string Name;
                std::string Type;
                float Value;
            };
            Field field;
        };
        Fields fields;

        class Methods {
        public:
            class Method {
            public:
                std::string Name;
                std::string ReturnType;

                class Statements {
                public:
                    class Statement {
                    public:
                        class DeclarationStatement {
                        public:
                            std::string Type;
                            std::string Name;
                            class Initializer {
                            public:
                                class Expression {
                                public:
                                    class BinaryOperator {
                                    public:
                                        std::string Operator;
                                        std::string LeftOperand;
                                        std::string RightOperand;
                                    };
                                    BinaryOperator binaryOperator;
                                };
                                Expression expression;
                            };
                            Initializer initializer;
                        };
                        DeclarationStatement declarationStatement;

                        class Expression {
                        public:
                            class CallExpression {
                            public:
                                std::string Target;
                                std::string MethodName;
                                std::string Argument;
                            };
                            CallExpression callExpression;
                        };
                        Expression expression;
                    };
                    Statement statement;
                };
                Statements statements;
            };
            Method method;
        };
        Methods methods;
    };
    MonoBehaviour monoBehaviour;
};

int main() {
    ScriptableObject scriptableObject;
    scriptableObject.monoBehaviour.ClassName = "ScreenSensitivity";
    scriptableObject.monoBehaviour.references.reference.Name = "UnityEngine";
    scriptableObject.monoBehaviour.fields.field.Name = "sensitivity";
    scriptableObject.monoBehaviour.fields.field.Type = "float";
    scriptableObject.monoBehaviour.fields.field.Value = 900f;
    scriptableObject.monoBehaviour.methods.method.Name = "Update";
    scriptableObject.monoBehaviour.methods.method.ReturnType = "void";

    // Configuración de la declaración y inicialización
    scriptableObject.monoBehaviour.methods.method.statements.statement.declarationStatement.Type = "Vector2";
    scriptableObject.monoBehaviour.methods.method.statements.statement.declarationStatement.Name = "input";
    scriptableObject.monoBehaviour.methods.method.statements.statement.declarationStatement.initializer.expression.binaryOperator.LeftOperand = "UnityEngine.Input.GetAxis(\"Mouse X\")";
    scriptableObject.monoBehaviour.methods.method.statements.statement.declarationStatement.initializer.expression.binaryOperator.RightOperand = "UnityEngine.Input.GetAxis(\"Mouse Y\")";
    
    // Configuración de la llamada a método
    scriptableObject.monoBehaviour.methods.method.statements.statement.expression.callExpression.Target = "transform";
    scriptableObject.monoBehaviour.methods.method.statements.statement.expression.callExpression.MethodName = "Rotate";
    scriptableObject.monoBehaviour.methods.method.statements.statement.expression.callExpression.Argument = "input * -sensitivity";

    // Imprimir para verificar los valores
    std::cout << "ClassName: " << scriptableObject.monoBehaviour.ClassName << std::endl;
    std::cout << "Field Name: " << scriptableObject.monoBehaviour.fields.field.Name << std::endl;
    std::cout << "Field Value: " << scriptableObject.monoBehaviour.fields.field.Value << std::endl;

    return 0;
}