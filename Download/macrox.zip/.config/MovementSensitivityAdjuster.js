let horizontalSensitivity = 900;
let verticalSensitivity = 900;

let horizontalInput = UnityEngine.Input.GetAxis("Horizontal") * horizontalSensitivity;
let verticalInput = UnityEngine.Input.GetAxis("Vertical") * verticalSensitivity;

transform.Translate(horizontalInput * UnityEngine.Time.deltaTime, 0, verticalInput * UnityEngine.Time.deltaTime);

return 0;
